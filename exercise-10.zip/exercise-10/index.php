<!DOCTYPE html>
<html>
	<head>
		<title>Exercise 10 - PHP Basics (Switch Statement)</title>
		<link href="css/myStyle.css" rel="stylesheet">
	</head>
	<body>
		<?php
			$h1 = '<h1>';
			$h1End = '</h1>';
			
			print "$h1 Exercise 10 - PHP Basics (Switch Statement) $h1End";
			
			$divClass = 'exercise'; # one of the classes defined in CSS file, myStyle.css inside css folder.
			
			$tr = '<tr>'; # store <tr> tag inside $tr variable. <tr> indicates start of row in a table.
			$trEnd = '</tr>'; # store </tr> tag inside $trEnd variable. </tr> indicates end of a row in a table.
			
			$th = '<th>'; # table header
			$thEnd = '</th>'; # end of table header
			
			$td = "<td>"; # store <td> tag inside $td variable. <td> indicates start of a cell in a table.
			$tdEnd = "</td>"; # store </td> tag inside $tdEnd variable. </td> indicates end of a cell in a table.
			
			$table = "<table>"; # store <table> tag inside $table variable. <table> indicates start of a table in an HTML page.
			$tableEnd = "</table>"; # store </table> tag inside $tableEnd variable. </table> indicates end of a table in an HTML page.
			
			$div = "<div class=$divClass>"; # <div class='exercise'> indicates start of a new section that falls under 'exercise' class (CSS).
			$divEnd = "</div>"; # </div> indicates end of the section.
			
			$p = "<p>"; # <p> indicates start of a paragraph in an HTML page.
			$pEnd = "</p>"; # </p> indicates end of a paragraph in an HTML page.
			
			$lineBreak = '<br>'; # line break in HTML page.
			$lessThan = '&lt;'; # '<' symbol
			$greaterThan = '&gt;'; # '>' symbol
			
		
			print $p;
				print "After completion of this exercise, you will learn to:
				       $lineBreak 1. Learn to use Switch statements in PHP.
					   $lineBreak 2. Differentiate between if/else if/else and Switch statments.
					   ";
			print $pEnd;
		?>
					
		<?php
		
			print $div;
				$text = "Your Grade: ";
				print "$p Example 1: If Statement $pEnd";
				
				$score = mt_rand(30, 100);
				
				print "$p Your Random Score: $score $pEnd";
				if($score >= 90)
					print "$p $text A $pEnd";
				else if($score >= 80)
					print "$p $text B $pEnd";
				else if ($score >= 70)
					print "$p $text C $pEnd";
				else if ($score >= 60)
					print "$p $text D $pEnd";
				else
					print "$p $text F $pEnd";
				
			print $divEnd;
			
			print $div;
				print "$p Example 2: Switch Statement $pEnd";
				
				$score = mt_rand(0, 100);
				print "$p Your Random Score: $score $pEnd";
				switch(intdiv($score, 10)){
					case 9:
					case 10:
						print "$p $text A $pEnd";
						
					case 8:
						print "$p $text B $pEnd";
						
					case 7:
						print "$p $text C $pEnd";
						
					case 6:
						print "$p $text D $pEnd";
						
					default: 
						print "$p $text F $pEnd";
				}
				
			print $divEnd;
			
			print $div;
				print "$p
						Problem 1: Explore Examples 1 and 2. 
						Both Example 1 and 2 address the same problem except for the fact that Example 1 uses if/else if/else
						where as Example 2 uses a switch statement to solve the problem.
						Do you agree with this statement? Please elaborate your answer. (10 Points) $lineBreak
						 - It does solve the same problem for getting the score right within the numbers. I tested the website by refreshing it and example 2 does solve the problem for example 1. $lineBreak
						Problem 2: Which approach did you find more convenient and why? (10 Points) $lineBreak
						 - I do think that example 2 is more convenient than example 1. It is a simple statement for the scores.$lineBreak
						Problem 3: Get rid of all the break statements inside the switch statement. 
						Refresh the page. Did you notice any anamoly here? Please explain. (10 Points) $lineBreak
						 - As the score was 98, it should be only displaying the letter A. However, it keep going and showed the other letters for the letter-grade score. Without break, the code won't stop within the loop.
						
					$pEnd
				";				
			print $divEnd;
			
			$sad = "&#128533;";
			$cross = "&#10006;";
			$tab = "&#9;";
			$happy = "&#128522;";
			$jubilant = "&#128525;";
			$angry = "&#128544;";
			$cry = "&#128546;";
			
			print $div;
				print "$p Example 3: Switch Statement $pEnd";
					$myMoodList = array('Sad', 'Happy', 'Jubilant', 'Angry', 'Crying'); # similar to list of strings in Python
					$currentMoodIndex = mt_rand(0, count($myMoodList) - 1); # Generating random index for myMoodList 
					$myCurrentMood = $myMoodList[$currentMoodIndex];
					print "My Mood: $myCurrentMood";
					
					switch($myCurrentMood){
						case 'Sad':
							print "$tab $sad";
							break;
						case 'Happy':
							print "$tab $happy";
							break;
						case 'Jubilant':
							print "$tab $jubilant";
							break;
						case 'Angry':
							print "$tab $angry";
							break;
						case 'Crying':
							print "$tab $cry";
							break;
						default: 
							print "$tab $cross Your code is incomplete. $cross";
					}
					
				print "$p Problem 4: Complete the switch statement shown above. 
							It should display all the moods defined in the array myMoodList. (20 Points) $lineBreak
						  Problem 5: Add at least 3 different moods (of your choice) to the array myMoodList and add cases to the switch statement (20 Points).
						$pEnd";
				
			print $divEnd;
			
			print $div;
				print "$p
						1. There should be no errors in your code (10 Points). $lineBreak
						2. You should provide a public link to your website 
					and I should be able to access it (10 Points). $lineBreak
						3. Upload index.php and a snapshot of your page (10 Points). $lineBreak
					$pEnd
				";
			print $divEnd;
		?>
	</body>
</html>