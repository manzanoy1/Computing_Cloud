<!DOCTYPE html>
<html>
	<head>
		<title>Exercise 11 - PHP Basics (Switch Statement and Loops)</title>
		<link href="css/myStyle.css" rel="stylesheet">
	</head>
	<body>
		<?php
			$h1 = '<h1>';
			$h1End = '</h1>';
			
			print "$h1 Exercise 11 - PHP Basics (Switch Statement and Loops) $h1End";
			
			$divClass = 'exercise'; # one of the classes defined in CSS file, myStyle.css inside css folder.
			
			$tr = '<tr>'; # store <tr> tag inside $tr variable. <tr> indicates start of row in a table.
			$trEnd = '</tr>'; # store </tr> tag inside $trEnd variable. </tr> indicates end of a row in a table.
			
			$th = '<th>'; # table header
			$thEnd = '</th>'; # end of table header
			
			$td = "<td>"; # store <td> tag inside $td variable. <td> indicates start of a cell in a table.
			$tdEnd = "</td>"; # store </td> tag inside $tdEnd variable. </td> indicates end of a cell in a table.
			
			$table = "<table>"; # store <table> tag inside $table variable. <table> indicates start of a table in an HTML page.
			$tableEnd = "</table>"; # store </table> tag inside $tableEnd variable. </table> indicates end of a table in an HTML page.
			
			$div = "<div class=$divClass>"; # <div class='exercise'> indicates start of a new section that falls under 'exercise' class (CSS).
			$divEnd = "</div>"; # </div> indicates end of the section.
			
			$p = "<p>"; # <p> indicates start of a paragraph in an HTML page.
			$pEnd = "</p>"; # </p> indicates end of a paragraph in an HTML page.
			
			$lineBreak = '<br>'; # line break in HTML page.
			$lessThan = '&lt;'; # '<' symbol
			$greaterThan = '&gt;'; # '>' symbol
			
			$ol = '<ol>';
			$olEnd = '</ol>';
			
			$ul = '<ul>';
			$ulEnd = '</ul>';
			
			$li = '<li>';
			$liEnd = '</li>';
			
			
			print "$p After completion of this exercise, you will learn to: $pEnd 
				$ol							
				   $li Learn to use Switch statements in PHP. $liEnd
				   $li Differentiate between if/else if/else and Switch statments. $liEnd
				   $li Learn to use For, While, and Do While loops in PHP. $liEnd
				   $li Learn to create array in PHP. $liEnd
				   $li Learn to create an ordered and unordered list in HTML using PHP. $liEnd
			   $olEnd
			   ";
			
		?>
					
		<?php
		
			print $div;
				$text = "Your Grade: ";
				print "$p Example 1: If Statement $pEnd";
				
				$score = mt_rand(50, 100);
				
				print "$p Your Random Score: $score $pEnd";
				if($score >= 93){
					print "$p Your letter grade is A. $pEnd";
				}else if($score >= 90){
					print "$p Your letter grade is A-. $pEnd";
				}elseif($score >= 87){
					print "$p Your letter grade is B+. $pEnd";
				}elseif($score >= 84){
					print "$p Your letter grade is B. $pEnd";
				}elseif($score >= 80){
					print "$p Your letter grade is B-. $pEnd";
				}elseif($score >= 77){
					print "$p Your letter grade is C+. $pEnd";
				}elseif($score >= 74){
					print "$p Your letter grade is C. $pEnd";
				}elseif($score >= 70){
					print "$p Your letter grade is C-. $pEnd";
				}elseif($score >= 67){
					print "$p Your letter grade is D+. $pEnd";
				}else if($score >= 63){
					print "$p Your letter grade is D. $pEnd";
				}else if($score >= 60){
					print "$p Your letter grade is D-. $pEnd";
				}else{
					print "$p Your letter grade is F. $pEnd";
				}
				
			print $divEnd;
			
			print $div;
				print "$p Problem 1: Switch Statement $pEnd";
				
				print "$p Your Random Score: $score $pEnd";
				switch($score){
					case $score >= 93:
						print "$p $text A $pEnd";
						break;
					case $score >= 90:
						print "$p $text A- $pEnd";
						break;
					case $score >= 87:
						print "$p $text B+ $pEnd";
						break;
					case $score >= 84:
						print "$p $text B $pEnd";
						break;
					case $score >= 80:
						print "$p $text B- $pEnd";
						break;
					case $score >= 77:
						print "$p $text C+ $pEnd";
						break;
					case $score >= 74:
						print "$p $text C $pEnd";
						break;
					case $score >= 70:
						print "$p $text C- $pEnd";
						break;
					case $score >= 67:
						print "$p $text D+ $pEnd";
						break;
					case $score >= 63:
						print "$p $text D $pEnd";
						break;
					case $score >= 60:
						print "$p $text D- $pEnd";
						break;
						
					default: 
						print "$p $text F $pEnd";
				}
			print $divEnd;
			
			print $div;
				print "	$ul
							$li Problem 1: Complete the Switch statement shown above so that it will 
							reflect this course's grading scheme (A, A-, B+, ...). (30 Points) $liEnd
							$li Problem 2: Which approach did you find more convenient and why? (10 Points) - the switch statement is more convinient than using the 'if' and 'else if'. It is simple and have a neat look in the script.  $liEnd
							$li Problem 3: Get rid of all the break statements(temporarily) inside the switch statement. 
							Refresh the page. Did you notice any anamoly here? 
							Do you think break statement is necessary? Please elaborate your answer. (10 Points)- - As the score was 74, it should be only displaying the letter C. However, it keep going and showed the other letters for the letter-grade score. Without break, the code won't stop and the letter grades will appear regardless of the score number. $liEnd
						$ulEnd
					";				
			print $divEnd;
			
			$sad = "&#128533;";
			$cross = "&#10006;";
			$tab = "&#9;";
			$happy = "&#128522;";
			$jubilant = "&#128525;";
			$angry = "&#128544;";
			$cry = "&#128546;";
			
			print $div;
				print "$p Example 2: Exploring an Array using a For Loop $pEnd";
					$myMoodList = array('Sad', 'Happy', 'Jubilant', 'Angry', 'Excited'); # similar to list of strings in Python
					$myCurrentMood = $myMoodList[0]; # accessing element stored at index 0 
					print "My Mood at Index 0: $myCurrentMood";
					print "$lineBreak $lineBreak";
					$sizeOfArray = count($myMoodList);
					
					# Using for loop to explore the element stored inside array $myMoodList
					for($index = 0; $index < $sizeOfArray; $index++){
						print "myMoodList[$index]: $myMoodList[$index] $lineBreak";
					}
					
					print "$p Example 3: Exploring an Array using a While Loop $pEnd";
					
					$index = 0;
					while($index < $sizeOfArray){
						print "myMoodList[$index]: $myMoodList[$index] $lineBreak";
						$index++;
					}
					
					print "$p Example 4: Exploring an Array using a Do While Loop $pEnd";
					
					$index = -1;
					do{
						++$index; # pre-increment, first do some task then check condition
						print "myMoodList[$index]: $myMoodList[$index] $lineBreak";
					
					}while($index < $sizeOfArray - 1); 
					# check condition to decide whether to stay or leave the loop
					
				print "$ul
							$li Problem 4: Get rid of index++ inside while loop temporarily. 
							Refresh your webiste's page, scroll down and analyze the output, and explain 
							the reason behind such unexpected output? (10 Points) - Apparently, if we get rid of index++ then the server will not function properly causing lag and gives messages about non-existing array keys. $liEnd
					   $ulEnd";
			print $divEnd;
			
			print $div;
				print "$ul 
						$li List at least three things you have learned from this class exercise. (10 Points) $liEnd
						$li There should be no errors in your code (10 Points). $liEnd
						$li You should provide a public link to your website 
						and I should be able to access it (10 Points). $liEnd
						$li Upload index.php and a snapshot of your page (10 Points). $liEnd
					  $ulEnd";
			print $divEnd;
		?>
	</body>
</html>