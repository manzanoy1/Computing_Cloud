<!DOCTYPE html>
<html>
	<head>
		<title>Exercise 12 - PHP Basics (Functions)</title>
		<link href="css/myStyle.css" rel="stylesheet">
	</head>
	<body>
		<?php
			$h1 = '<h1>';
			$h1End = '</h1>';
			
			$divClass = 'exercise'; # one of the classes defined in CSS file, myStyle.css inside css folder.
			
			$tr = '<tr>'; # store <tr> tag inside $tr variable. <tr> indicates start of row in a table.
			$trEnd = '</tr>'; # store </tr> tag inside $trEnd variable. </tr> indicates end of a row in a table.
			
			$th = '<th>'; # table header
			$thEnd = '</th>'; # end of table header
			
			$td = "<td>"; # store <td> tag inside $td variable. <td> indicates start of a cell in a table.
			$tdEnd = "</td>"; # store </td> tag inside $tdEnd variable. </td> indicates end of a cell in a table.
			
			$table = "<table>"; # store <table> tag inside $table variable. <table> indicates start of a table in an HTML page.
			$tableEnd = "</table>"; # store </table> tag inside $tableEnd variable. </table> indicates end of a table in an HTML page.
			
			$div = "<div class=$divClass>"; # <div class='exercise'> indicates start of a new section that falls under 'exercise' class (CSS).
			$divEnd = "</div>"; # </div> indicates end of the section.
			
			$p = "<p>"; # <p> indicates start of a paragraph in an HTML page.
			$pEnd = "</p>"; # </p> indicates end of a paragraph in an HTML page.
			
			$lineBreak = '<br>'; # line break in HTML page.
			$lessThan = '&lt;'; # '<' symbol
			$greaterThan = '&gt;'; # '>' symbol
			
			$ol = '<ol>';
			$olEnd = '</ol>';
			
			$ul = '<ul>';
			$ulEnd = '</ul>';
			
			$li = '<li>';
			$liEnd = '</li>';
			
			print $div;
				print "$h1 Exercise 12 - PHP Basics (Functions) $h1End";
				
				print "$p After completion of this exercise, you will learn to: $pEnd 
					$ol							
					   $li Use functions in PHP. $liEnd
					   $li Create and manipulate elements in array in PHP. $liEnd
					   $li Learn to create an ordered and unordered list in HTML using PHP. $liEnd
				   $olEnd
				   ";
			print $divEnd;
		?>
					
		<?php
			# store unicode for different emojis and a tab
			$sad = "&#128533;";
			$cross = "&#10006;";
			$tab = "&#9;";
			$happy = "&#128522;";
			$jubilant = "&#128525;";
			$angry = "&#128544;";
			$cry = "&#128546;";
			
			$myMoodList = array($sad, $happy, $jubilant, $angry, $cry);
			printMoodsInUnorderedList('Example 1: A function that prints a section containing a list of moods.', $myMoodList);
			
			# Add another mood variable in $myMoodList
			$cool =  "&#128526;";
			
			# append the unicode for cool emoji in the array $myMoodList.
			array_push($myMoodList, $cool);
			
			# call the function again.
			printMoodsInUnorderedList('Example 2: Printing array/list after adding an emoji.', $myMoodList);
			
			$content = "Problem 1: Create another variable and store HTML code
							for emojis of your choice. Next, append the new emoji to the 
							array/list myMoodList. 
							Next, call the function printMoodsInUnorderedList('Problem 1', myMoodList) (20 Points). 
						";
					  
			printSection($content);
			
			# Your code for Problem 1 starts here ...
			
			$skull = "&#128128;";
			
			array_push($myMoodList, $skull);
			
			printMoodsInUnorderedList("Problem 1", $myMoodList);
			
			# remove the last element of the array myMoodList.
			array_pop($myMoodList); 
			printMoodsInUnorderedList('Example 3: Pop an element of the array.', $myMoodList);
			
			
			$content = "Problem 2: Remove/pop at least three items from the array (20 Points). 
						";
					  
			printSection($content);
			
			# Your code for Problem 2 starts here ...
			
			array_pop($myMoodList);
			array_pop($myMoodList);
			array_pop($myMoodList);
			printMoodsInUnorderedList("Problem 2", $myMoodList);
			
			
			# Do not modify the code after this point.
			
			function printMoodsInUnorderedList($msg, $myMoodList){
				global $div, $divEnd, $p, $pEnd, $ul, $ulEnd, $li, $liEnd;
				print $div;
					print "$p $msg $pEnd";
					print $ul;
						foreach($myMoodList as $mood){
							print "$li $mood $liEnd";
						}
					
					print $ulEnd;
				print $divEnd;
			}
			
			function printSection($msg){
				global $div, $divEnd, $ul, $ulEnd, $li, $liEnd;
				
				print $div;
					print "$ul 
							$li $msg $liEnd
						  $ulEnd";
				print $divEnd;
				
			}
			
			# Update this code to list at least three things you have learned in this exercise.
			print $div;
				print "$p Today I learned to: $pEnd";
				print "$ul 
						$li Use AWS Elastic Beanstalk. $liEnd
						$li Add at least three more ... $liEnd
					$ulEnd";
			print $divEnd;
			
			print $div;
				print "$p To Do List: $pEnd";
				print "$ul 
						$li List at least three things you have learned from this class exercise (10 Points). $liEnd
						$li There should be no errors in your code (10 Points). $liEnd
						$li Compress your code to create a zip file and 
						    upload the file on Amazon S3 using AWS Elastic Beanstalk (20 Points). $liEnd
						$li Upload the zip file on D2L as well (10 Points). $liEnd
						$li Please provide a link to your website on D2L (10 Points). $liEnd
					$ulEnd";
			print $divEnd;
		?>
	</body>
</html>