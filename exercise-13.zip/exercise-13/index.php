<!DOCTYPE html>
<html>
	<head>
		<title>Exercise 13 - PHP Basics (Arrays, Functions, and HTML5 Lists) </title>
		<link href="css/myStyle.css" rel="stylesheet">
	</head>
	<body>
		<?php
			$h1 = '<h1>';
			$h1End = '</h1>';
			
			$divClass = 'exercise'; # one of the classes defined in CSS file, myStyle.css inside css folder.
			
			$tr = '<tr>'; # store <tr> tag inside $tr variable. <tr> indicates start of row in a table.
			$trEnd = '</tr>'; # store </tr> tag inside $trEnd variable. </tr> indicates end of a row in a table.
			
			$th = '<th>'; # table header
			$thEnd = '</th>'; # end of table header
			
			$td = "<td>"; # store <td> tag inside $td variable. <td> indicates start of a cell in a table.
			$tdEnd = "</td>"; # store </td> tag inside $tdEnd variable. </td> indicates end of a cell in a table.
			
			$table = "<table>"; # store <table> tag inside $table variable. <table> indicates start of a table in an HTML page.
			$tableEnd = "</table>"; # store </table> tag inside $tableEnd variable. </table> indicates end of a table in an HTML page.
			
			$div = "<div class=$divClass>"; # <div class='exercise'> indicates start of a new section that falls under 'exercise' class (CSS).
			$divEnd = "</div>"; # </div> indicates end of the section.
			
			$p = "<p>"; # <p> indicates start of a paragraph in an HTML page.
			$pEnd = "</p>"; # </p> indicates end of a paragraph in an HTML page.
			
			$lineBreak = '<br>'; # line break in HTML page.
			$lessThan = '&lt;'; # '<' symbol
			$greaterThan = '&gt;'; # '>' symbol
			
			$ol = '<ol>';
			$olEnd = '</ol>';
			
			$ul = '<ul>';
			$ulEnd = '</ul>';
			
			$li = '<li>';
			$liEnd = '</li>';
			
			$b = '<b>';
			$bEnd = '</b>';
			
			print $div;
				print "$h1 Exercise 13 - PHP Basics (Arrays, Functions, and HTML5 Lists) $h1End";
				
				print "$p After completion of this exercise, you will learn to: $pEnd 
					$ol							
					   $li Use functions in PHP. $liEnd
					   $li Create and manipulate elements in array in PHP. $liEnd
					   $li Learn to create an ordered and unordered list in HTML using PHP. $liEnd
				   $olEnd
				   ";
			print $divEnd;
		?>
					
		<?php
		
			$requirement_1 = "Each Group Member Should Collect at Least: $b 100 Points $bEnd";
			$requirement_2 = "Your Project incorporates:
								$ul 
									$li Amazon S3: $b 10 Points $bEnd $liEnd 
									$li Amazon EC2: $b 30 Points $bEnd $liEnd
									$li AWS Elastic Beanstalk: $b 30 Points $bEnd $liEnd
									$li Amazon RDS or Amazon DynamoDB: $b 30 Points $bEnd $liEnd
									$li AWS Lambda: $b 30 Points $bEnd $liEnd
								$ulEnd";
			
			$requirement_3 = "Evaluation of Quality of Your Peer Review: $b 10 Points per Member $bEnd";
			$requirement_4 = "Evaluation of Your Work from Your Peers: $b 30 Points per Member $bEnd";
			$requirement_5 = "Project Demonstration: $b 10 Points per Member $bEnd";
			$requirement_6 = "Overall Quality of Your Application: $b 10 Points per Member $bEnd";
			$requirement_7 = "Submission of Code and Data Related to Your Project: $b 10 Points per Member $bEnd";
			$requirement_8 = "Project Demonstration Date: $b Probably the Final Exam Day $bEnd";
			$requirement_9 = "Deadline for Project Related Code and Data: $b November 30, 2022 $bEnd";
			$requirement_10 = "More than 20% Work Derived from Someone Else's Project(s): $b -50 Points For Each Group Member $bEnd";
			$requirement_11 = "Late Submission: $b -50 Points For Each Group Member $bEnd";
			$requirement_12 = "Project Report (Must Include Group Member Contribution): $b 20 Points $bEnd";
			
			
			
			$projectRequirements = array($requirement_1, 
										 $requirement_2, 
										 $requirement_3,
										 $requirement_4,
										 $requirement_5,
										 $requirement_6
										 );
			
			
			$content = 'Problem 1: Push more requirements (elements) to the array $projectRequirements below (10 Points).';
			printSection($content);
			
			# Push all the remaining elements here, i.e., $requirement_9,  $requirement_10, and so on.
			array_push($projectRequirements, $requirement_7, $requirement_9, $requirement_10, $requirement_11, $requirement_12);
			
			print "$p Computing in the Cloud Project Requirements $pEnd";
			printProjectRequirements($projectRequirements);
						
			print $div;
				print "$p Case 1: Let's assume that you are working alone for your project 
						and you have decided to use AWS Elastic Beanstalk for your project. $pEnd";
				
				# Problem 2: Call function printFulfilledRequirements to print an example of fulfilled requirements. (10 Points)
				printSection("Call Function printFulfilledRequirements() ... (10 Points)");
				
				printProjectRequirements($projectRequirements);
				
				print "$p Total Points Acquired: $b 90 $bEnd $pEnd";
				print "$p Minimum Points Required: $b 85 $bEnd $pEnd";
				print "$p You Individual Score for the Project: $b 90% $bEnd $pEnd";
			
			print $divEnd;
			
			print $div;
				print "$p Case 2: Let's assume your group has 2 members 
							and you have decided to use AWS Elastic Beanstalk for your project. $pEnd";
						
				# Problem 2: Call function printFulfilledRequirements to print an example of fulfilled requirements. (10 Points)
				printSection("Call Function printFulfilledRequirements() ... (10 Points)");	
				
				printProjectRequirements($projectRequirements);
				
				print "$p Total Points Acquired: $b 170 $bEnd $pEnd";
				print "$p Minimum Points Required: $b 200 $bEnd $pEnd";
				print "$p You Individual Score for the Project: $b 85% $bEnd $pEnd";
				print "Suggestion: You may want to incorporate 
						Amazon RDS to get 30 more points. 
						This way your group will accumulate 200 points.";
				
			print $divEnd;
			
			# Update this code to list at least three things you have learned in this exercise.
			print $div;
				print "$p Today I learned: $pEnd";
				print "$ul 
						$li Project Requirements $liEnd
						$li Add at least three more ... $liEnd
						$li Array_push the elements into the function.$liEnd
						$li Calculate the scores for the project, each individually and group.$liEnd
						$li Using $/li for rows in this exercise.$liEnd
					$ulEnd";
			print $divEnd;
			
			print $div;
				print "$p To Do List: $pEnd";
				print "$ul 
						$li List at least three things you have learned from this class exercise (10 Points). $liEnd
						$li There should be no errors in your code (10 Points). $liEnd
						$li Your website content should be exactly the same as the sample provided to you. (10 Points). $liEnd
						$li Compress your code to create a zip file and upload the file on AWS Elastic Beanstalk (20 Points). $liEnd
						$li Upload the zip file on D2L as well (10 Points). $liEnd
						$li Please provide a link to your website on D2L (10 Points). $liEnd
					$ulEnd";
			print $divEnd;
			
		?>
		
		
		<?php
			# Restricted Area: Do Not Modify This
			
			function printFulfilledRequirements(){
				global $b, $bEnd, $requirement_3, $requirement_4, $requirement_5, $requirement_6, $requirement_7;
				$requirement_fulfilled = array(
												"AWS Elastic Beanstalk: $b 30 Points $bEnd",
												$requirement_3,
												$requirement_4,
												$requirement_5,
												$requirement_6,
												$requirement_7
											);
				printProjectRequirements($requirement_fulfilled);
			}
			
			function printProjectRequirements($requirement){
				global $div, $divEnd, $ol, $olEnd, $li, $liEnd;
				
				print $div;
					print $ol;
						foreach($requirement as $item){
							print "$li $item $liEnd";
						}
					print $olEnd;
				
				print $divEnd;
				
			}
			
			function printSection($msg){
				global $div, $divEnd, $ul, $ulEnd, $li, $liEnd;
				
				print $div;
					print "$ul 
							$li $msg $liEnd
						  $ulEnd";
				print $divEnd;
				
			}
			
		?>
	</body>
</html>