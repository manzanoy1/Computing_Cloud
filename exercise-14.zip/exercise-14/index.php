<!DOCTYPE html>
<html>
	<head>
		<title>Class Exercise 14</title>
		<link href="css/myStyle.css" rel="stylesheet">
	</head>
	<body>
		<?php
			$h1 = '<h1>';
			$h1End = '</h1>';
			
			$divClass = 'exercise'; # one of the classes defined in CSS file, myStyle.css inside css folder.
			
			$tr = '<tr>'; # store <tr> tag inside $tr variable. <tr> indicates start of row in a table.
			$trEnd = '</tr>'; # store </tr> tag inside $trEnd variable. </tr> indicates end of a row in a table.
			
			$th = '<th>'; # table header
			$thEnd = '</th>'; # end of table header
			
			$td = "<td>"; # store <td> tag inside $td variable. <td> indicates start of a cell in a table.
			$tdEnd = "</td>"; # store </td> tag inside $tdEnd variable. </td> indicates end of a cell in a table.
			
			$table = "<table>"; # store <table> tag inside $table variable. <table> indicates start of a table in an HTML page.
			$tableEnd = "</table>"; # store </table> tag inside $tableEnd variable. </table> indicates end of a table in an HTML page.
			
			$div = "<div class=$divClass>"; # <div class='exercise'> indicates start of a new section that falls under 'exercise' class (CSS).
			$divEnd = "</div>"; # </div> indicates end of the section.
			
			$p = "<p>"; # <p> indicates start of a paragraph in an HTML page.
			$pEnd = "</p>"; # </p> indicates end of a paragraph in an HTML page.
			
			$lineBreak = '<br>'; # line break in HTML page.
			$lessThan = '&lt;'; # '<' symbol
			$greaterThan = '&gt;'; # '>' symbol
			
			$ol = '<ol>';
			$olEnd = '</ol>';
			
			$ul = '<ul>';
			$ulEnd = '</ul>';
			
			$li = '<li>';
			$liEnd = '</li>';
			
			$b = '<b>';
			$bEnd = '</b>';
			
			$maxPoints = 0;
			$problemCount = 0;
			
			$star = "&#10032;";
			
			print $div;
				print "$h1 Exercise 14 - AWS Elastic Beanstalk and PHP Basics (Revision) $h1End";
			print $divEnd;
			
		?>
					
		<?php
			printProblemsToSolve("Create an array myFavoriteFruits that stores at least 5 fruits.", 10);
			
			# Code for Problem 1 Starts Here
			
			$apple = "apple";
			$pear = "pear";
			$coconut = "coconut";
			$blueberry = "blueberry";
			$cherry = "cherry";
			
			$myFavoriteFruits = array($apple, $pear, $coconut, $blueberry, $cherry);
			
			printProblemsToSolve("Print names of the fruits stored inside the array 
									you have created above (use for and foreach loops).", 10);
			array_push($myFavoriteFruits);
			
			
			print "$p Using a foreach loop: $pEnd";
			# Code for Problem 2 Starts Here
			
			foreach($myFavoriteFruits as $item){
				print "$star $item";
			}
				
			print "$p Using a for loop: $pEnd";
			# Code for Problem 2 Starts Here
			for ($i=0; $i< count($myFavoriteFruits); $i++)
				print "$star $myFavoriteFruits[$i]";
			
			print "$lineBreak $lineBreak";
			
			printProblemsToSolve("Use a while loop to print numbers from 1 to 20.", 10);
			# Code for Problem 3 Starts Here
			$y = 1;
			while($y <= 20){
				print "$y ";
				$y++;
			}
			
			print "$lineBreak $lineBreak";
			
			printProblemsToSolve("Use a do while loop to print even numbers from 1 to 20.", 10);
			# Code for Problem 4 Starts Here
			
			$x = 1;

			do {
					if($x%2==0){
						print "$x ";
					}
					$x++;
			}	while ($x <= 20);
				
			
			print "$lineBreak $lineBreak";
			
			printProblemsToSolve('Sort the array $myFavoriteFruits 
								you have created above and print it again (call functions sort($YourArray) or rsort($YourArray)): ', 10);
			
			# Code for Problem 5 Starts Here
			print $div;
			foreach($myFavoriteFruits as $item){
				print "$star $item";
			}
			print $divEnd;
			
			print $div;
			rsort($myFavoriteFruits);
			foreach($myFavoriteFruits as $item){
				print "$star $item";
			}
			print $divEnd;
			
			printProblemsToSolve("Locate and make changes to function printTable() such that
									it will print a 5X5 table as shown in the sample webpage: ", 20);
			
			printTable();
			
			print $div;
				updateScore(30);
				print "$ol
						$li There should be no errors/warnings in your code (10 Points). $liEnd
						$li You should provide a full functioning AWS Elastic Beanstalk link (10 Points). $liEnd
						$li Upload zip file containing index.php and css folder on D2L. (10 Points). $liEnd
						$li Total Points: $b $maxPoints $bEnd $liEnd
					$olEnd
				";
			print $divEnd;
		?>
		
		<?php
			function printItemLists($myArray){
				global $div, $divEnd, $star;
				print $div;				
					foreach($myArray as $item){
						print "$star $item ";
					}
				print $divEnd;
			}
			
			function printTable(){
				global $table, $tableEnd, $tr, $trEnd, $td, $tdEnd;
				print $table;
					print "$tr
							$td (0, 0) $tdEnd
							$td (0, 1) $tdEnd
							$td (0, 2) $tdEnd
							$td (0, 3) $tdEnd
							$td (0, 4) $tdEnd
						$trEnd";
					
					print "$tr
							$td (1, 0) $tdEnd
							$td (1, 1) $tdEnd
							$td (1, 2) $tdEnd
							$td (1, 3) $tdEnd
							$td (1, 4) $tdEnd
						$trEnd";
						
					print "$tr
							$td (2, 0) $tdEnd
							$td (2, 1) $tdEnd
							$td (2, 2) $tdEnd
							$td (2, 3) $tdEnd
							$td (2, 4) $tdEnd
						$trEnd";
					
					print "$tr
							$td (3, 0) $tdEnd
							$td (3, 1) $tdEnd
							$td (3, 2) $tdEnd
							$td (3, 3) $tdEnd
							$td (3, 4) $tdEnd
						$trEnd";
						
					print "$tr
							$td (4, 0) $tdEnd
							$td (4, 1) $tdEnd
							$td (4, 2) $tdEnd
							$td (4, 3) $tdEnd
							$td (4, 4) $tdEnd
						$trEnd";
				print $tableEnd;
			}
			
			function printExamples($description){
				global $div, $divEnd, $p, $pEnd, $listOfFruits, $example_counter;
				++$example_counter;
				print $div;
					print "$p Example $example_counter: $description. $pEnd";
					printItemLists($listOfFruits);
				print $divEnd;
			}
			
			function printProblemsToSolve($problem_description, $points){
				global $div, $divEnd, $p, $pEnd, $maxPoints, $problemCount;
				++$problemCount;
				print $div;
					print "$p Problem $problemCount: $problem_description ($points Points) $pEnd";
					updateScore($points);
				print $divEnd;
			}
			
			function updateScore($score){
				global $maxPoints;
				$maxPoints += $score;
			}
		?>
	</body>
</html>