<!DOCTYPE html>
<html>
	<head>
		<title>Class Exercise 19</title>
		<link href="css/myStyle.css" rel="stylesheet">
	</head>
	<body>
		<?php
			include 'utility/htmlTags.php';
			include 'utility/database.php';
			include 'utility/exercise.php';
			
			print $div;
				print "$h1 Exercise 19 - Amazon RDS $h1End";
			print $divEnd;
			
			updateLearningObjective($learningObjectives, 
									'Connect to DB Instance you have created using Amazon RDS.');
			updateLearningObjective($learningObjectives, 
									'Fetch raw data for tables stored inside database university.');
		
			printLearningObjectives($learningObjectives);
			
			
			updateRules($rules, 'Upload a zip file containing all the code related files and folders.', 10);
			updateRules($rules, 'Print your web page (Ctrl + P) and upload the printed page on D2L 
								or upload snapshots of your updated web page.', 10);
			
		?>
					
		<?php
		
			printExamples("Print Database Connection Information: ");
			
			$myServer = 'cisc320-yanira-1.cwqya4upwyw5.us-east-2.rds.amazonaws.com';
			$myUserName = 'admin';
			$myPassword = 'h3254807';
			$databaseName = 'cisc320-yanira-1';
			$myDB = new Database($myServer, $myUserName, $myPassword, $databaseName);
			$myDB -> printConnectionDetails();
			
			printProblemsToSolve("Edit the variables to store your Database Connection Information. ", 15);
			
			printExamples("Connecting to the Database Using Infomation Shown Above: ");
			$myDB->connectToDatabase();
			
			printExamples("Fetching Records/Rows from Table Students: ");
			$myDB->fetchAllRows('students');
			
			printProblemsToSolve("Call fetchAllRows(...) function to display raw data for table courses. ", 30);
			# Type Your Code Here ...
			$myDB->fetchAllRows('courses');
			
			printProblemsToSolve("Call fetchAllRows(...) function to display raw data for table student_course. ", 30);
			# Type Your Code Here ...
			$myDB->fetchAllRows('student_course');
					
			printProblemsToSolve("Close the database connection. ", 5);
			# Type Your Code Here ...
			$myDB->closeDatabaseConnection();
			
			# DO NOT MODIFY AFTER THIS POINT
			printRules($rules);
		?>
	</body>
</html>