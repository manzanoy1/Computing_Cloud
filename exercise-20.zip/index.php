<!DOCTYPE html>
<html>
	<head>
		<title>Class Exercise 20</title>
		<link href="css/myStyle.css" rel="stylesheet">
	</head>
	<body>
		<?php
			include 'utility/htmlTags.php';
			include 'utility/database.php';
			include 'utility/exercise.php';
			
			print $div;
				print "$h1 Exercise 20 - Amazon RDS $h1End";
			print $divEnd;
			
			updateLearningObjective($learningObjectives, 
									'Connect to DB Instance you have created using Amazon RDS.');
			updateLearningObjective($learningObjectives, 
									'Fetch raw data from tables and display it properly in the web page.');
			
			printLearningObjectives($learningObjectives);
			
			
			updateRules($rules, 'Upload a zip file containing all the code related files and folders.', 10);
			updateRules($rules, 'Print your web page (Ctrl + P) and upload the printed page on D2L 
								or upload snapshots of your updated web page.', 10);
			
		?>
					
		<?php
		
			printExamples("Print Database Connection Information: ");
			
			$myServer = 'cisc320-yanira-1.cwqya4upwyw5.us-east-2.rds.amazonaws.com';
			$myUserName = 'admin';
			$myPassword = 'h3254807';
			$databaseName = 'university';
			$myDB = new Database($myServer, $myUserName, $myPassword, $databaseName);
			$myDB -> printConnectionDetails();
			
			printProblemsToSolve("Edit the variables to store your Database Connection Information. ", 5);
			
			printExamples("Connecting to the Database Using Infomation Shown Above: ");
			$myDB->connectToDatabase();
			
			printExamples("Fetching Records/Rows from Table Students and Display it Properly: ");
			$myDB->printRecords('students');
			
			printProblemsToSolve("Call printRecords(...) function that belongs to Database class to display rows for table courses. ", 30);
			# Type Your Code Here ...
			$myDB->printRecords('courses');
						
			printExamples("Calling executeQueryAndPrintRecords(...) function 
								that executes your query and displays the returned result set in your web page.");
			$myDB->executeQueryAndPrintRecords("SELECT *
												FROM students
												WHERE student_id = 1"
											   );

			printProblemsToSolve("Similar to one shown in the previous example, 
									call function executeQueryAndPrintRecords(...) 
									to execute your query that displays first and last name of students whose last names starts with S. ", 20);
			# Type Your Code Here ...
			$myDB->executeQueryAndPrintRecords("SELECT student_first_name, student_last_name
												FROM students
												WHERE student_last_name LIKE 'S%'"
											   );
			
			printProblemsToSolve("Similar to one shown in the previous example, 
									call function executeQueryAndPrintRecords(...) 
									to execute your query that display students whose last names ends with with S. ", 20);
			# Type Your Code Here ...
			$myDB->executeQueryAndPrintRecords("SELECT student_first_name, student_last_name
												FROM students
												WHERE student_last_name LIKE '%S'"
											   );
			
			printProblemsToSolve("CHALLENGE PROBLEM: Similar to one shown in the previous example, 
									call function executeQueryAndPrintRecords(...) 
									to execute your query that display full name,
									courses, and respective grades of students
									who are enrolled in courses that starts with D. ", 0);
			
			# Type Your Code Here ...
			$myDB->executeQueryAndPrintRecords("SELECT student_first_name,
												student_last_name,
												course_name,
												course_grade
												FROM student_course sc
													JOIN students s
														ON sc.student_id = s.student_id
													JOIN courses c
														ON sc.course_id = c.course_id
													WHERE c.course_name LIKE 'D%';"
											   );
			printProblemsToSolve("Close the database connection. ", 5);
			
			# Type Your Code Here ...
			$myDB->closeDatabaseConnection();
			
			
			# DO NOT MODIFY BELOW THIS LINE
			printRules($rules);
		?>
	</body>
</html>