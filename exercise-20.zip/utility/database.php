<?php
	
	/*
		Copyright @ Romas James Hada
	*/
	
	class Database{
		private $server;
		private $userName;
		private $password;
		private $database;
		private $port;
		private $connection;
		
		function __construct($server, $userName, $password, $database){
			$this->server = $server;
			$this->userName = $userName;
			$this->password = $password;
			$this->database = $database;
			$this->port = '3306';

		}
					
		function setDatabasePort($newPortAddress){
				$this->port = $newPortAddress;
		}
		
		function printConnectionDetails(){
			global $ul, $ulEnd, $li, $liEnd, $div, $divEnd;
			
			print $div;
				print $ul;
					print "
							$li Server: $this->server $liEnd
							$li User Name: $this->userName $liEnd
							$li Database: $this->database $liEnd
							$li Port Address: $this->port $liEnd
						";
				print $ulEnd;
			print $divEnd;
			
		}
		
		function connectToDatabase(){
			global $p, $pEnd, $div, $divEnd;
			print $div;
				$this->connection = new mysqli($this->server, $this->userName, $this->password, $this->database, $this->port);
			
				if ($this->connection->connect_error) {
				  die("$p connection Failed: $connection->connectionect_error $pEnd");
				}else{
					print "$p Database connection was successful! $pEnd";
				}
			print $divEnd;
		}
		
		function closeDatabaseConnection(){
			global $p, $pEnd, $div, $divEnd;
			
			print $div;
				$this->connection->close();
				if ($this->connection->connect_error) 
					print "$p Something went wrong! Datbase connection could not be terminated. $pEnd";
				else
					print "$p Database successfully disconnected! $pEnd";
			print $divEnd;
		}
		
		function fetchAllRows($table){
			global $p, $pEnd, $div, $divEnd, $lineBreak;
			
			print $div;
				if($this->connection){
					$sql = "SELECT * FROM $table";
					$result = $this->connection->query($sql);
					
					if($result){
						print "$p Total Rows/Records in $table: $result->num_rows $pEnd";
					}
					
					while($rows = $result->fetch_assoc()){
						var_dump($rows);
						print "$lineBreak $lineBreak $lineBreak";
					}							
				}
			print $divEnd;
		}
		
		function printRecords($table){
			global $p, $pEnd, $div, $divEnd, $lineBreak;
			
			print $div;
				if($this->connection){
					$sql = "SELECT * FROM $table";
					$result = $this->connection->query($sql);
					
					if($result){
						print "$p Total Rows/Records: $result->num_rows $pEnd";
					}
					
					while($rows = $result->fetch_assoc()){
						$this->printRow($rows);
						print("$lineBreak $lineBreak");
					}							
				}
			print $divEnd;
		}
		
		function printRow($assocArray){
			global $lineBreak, $div, $divEnd, 
					$table, $tableEnd, $tr, $trEnd, $td, $tdEnd,
					$b, $bEnd;
			print $div;
				print $table;
				foreach($assocArray as $column => $value){
					print "$tr $td $b $column $bEnd $tdEnd $td $value $tdEnd $trEnd";
				}
				print $tableEnd;
			print $divEnd;
			
		}
		
		function executeQueryAndPrintRecords($sql){
			global $p, $pEnd, $div, $divEnd, $lineBreak;
			
			print $div;
				if($this->connection){
					$result = $this->connection->query($sql);
					
					if($result){
						print "$p Total Rows/Records: $result->num_rows $pEnd";
					}
					
					if($result->num_rows > 0){
						while($rows = $result->fetch_assoc()){
							$this->printRow($rows);
							print("$lineBreak $lineBreak");
						}	
					}
											
				}
			print $divEnd;
		}
	}
?>