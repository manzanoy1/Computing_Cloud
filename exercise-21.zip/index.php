<!DOCTYPE html>
<html>
	<head>
		<title>Class Exercise 21</title>
		<link href="css/myStyle.css" rel="stylesheet">
	</head>
	<body>
		<?php
			include 'utility/htmlTags.php';
			include 'utility/database.php';
			include 'utility/exercise.php';
			
			print $div;
				print "$h1 Exercise 21 - Amazon RDS $h1End";
			print $divEnd;
			
			updateLearningObjective($learningObjectives, 
									'Connect to DB Instance you have created using Amazon RDS.');
									updateLearningObjective($learningObjectives, 
									'Insert new records and update tables in the database using PHP.');
			updateLearningObjective($learningObjectives, 
									'Fetch raw data from tables, process it, and display it properly in the web page.');
			updateLearningObjective($learningObjectives, 
									'Close the database connection once you accomplish specified tasks.');
							
			printLearningObjectives($learningObjectives);
			
			
			updateRules($rules, 'Upload a zip file containing all the code related files and folders.', 10);
			updateRules($rules, 'Print your web page (Ctrl + P) and upload the printed page on D2L 
								or upload snapshots of your updated web page.', 10);
			
		?>
					
		<?php
		
			printExamples("Print Database Connection Information: ");
			
			$myServer = 'cisc320-yanira-1.cwqya4upwyw5.us-east-2.rds.amazonaws.com';
			$myUserName = 'admin';
			$myPassword = 'h3254807';
			$databaseName = 'university';
			$myDB = new Database($myServer, $myUserName, $myPassword, $databaseName);
			$myDB -> printConnectionDetails();
			
			printProblemsToSolve("Edit the variables to store your Database Connection Information. ", 5);
			
			printExamples("Connecting to the Database Using Infomation Shown Above: ");
			$myDB->connectToDatabase();
			
			printProblemsToSolve("Where does the student with ID 3 lives? 
								  Your Answer Starts Here ... -The student lives in 123 Pine Lake, Las Vegas, NY 89119", 10);
			
			printExamples("Fetching Records/Rows for Student with Student ID 3: ");
			$sql= 'SELECT * 
				   FROM students	
				   WHERE student_id = 3';
			$myDB->executeQueryAndPrintRecords($sql);
			
			printExamples("Execute a query that updates an existing record in table students inside database university: ");
			$sql = "UPDATE students
					SET student_state = 'NV'
					WHERE student_id = 3";
			$myDB->executeQueryToInsertOrUpdateRows($sql);
			
			printExamples("Fetching Records/Rows for Student with Student ID 3 After Update: ");
			$sql= 'SELECT * 
				   FROM students	
				   WHERE student_id = 3';
				
			$myDB->executeQueryAndPrintRecords($sql);
			
			
			printProblemsToSolve("As shown in the prior example, 
								change the student's city to Carson City from Las Vegas. ", 30);
			
			# Your Code Starts Here ...
			$sql = "UPDATE students
					SET student_city = 'Carson City'
					WHERE student_id = 3";
					
			$myDB->executeQueryToInsertOrUpdateRows($sql);

			printProblemsToSolve("Where does the student with ID 3 lives now? 
								Did you see any changes compared to your answer in Problem 1? 
								Your Answer Starts Here ... -The student lives 123 Pine Lake, Carson City, NV 89119 ", 10);
		
			
			printExamples("Inserting a new record to the database: ");
			
			$sql = "
					INSERT INTO students (student_first_name, student_last_name, 
										  student_address, student_city, student_state, student_zipcode, 
										  student_dob, student_ssn) 
					VALUES ('Maximo', 'Grant', '7 Star Wars Drive', 'Catskill', 'NY', '12414', 
							'1999-9-9', '899-125-380')
					";
			$myDB->executeQueryToInsertOrUpdateRows($sql);
			$myDB->printRecords('students');
			
			printProblemsToSolve("Similar to the prior example, insert a new record in the table students 
								  that represents you. 
								  Do not use your real address, DOB, and SSN except for your first and last name.
									", 20);
			# Your Code Starts Here ...
			$sql = "
					INSERT INTO students (student_first_name, student_last_name, 
										  student_address, student_city, student_state, student_zipcode, 
										  student_dob, student_ssn) 
					VALUES ('Yanira', 'Manzano', '7 Star Wars Drive', 'Catskill', 'NY', '12414', 
							'10-31-2000', '458-48-753')
					";
			$myDB->executeQueryToInsertOrUpdateRows($sql);
			$myDB->printRecords('students');
			printProblemsToSolve("Close the database connection. ", 5);
			# Type Your Code Here ...
			$myDB->closeDatabaseConnection();
			
			printRules($rules);
		?>
	</body>
</html>