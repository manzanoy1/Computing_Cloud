<!DOCTYPE html>
<html lang="en">
	<head>
		<title> Add Student Profile </title>
		<link href="../css/myStyle.css" type="text/css" rel="stylesheet">
		<script src='profile.js'> </script>
	</head>
	<body>
		<?php
			require 'database.php';
			require 'student.php';
			require 'htmlTags.php';
			session_start(); 
		?>
		<h1>ADD STUDENT'S PROFILE</h1>
		<form id='record' action="<?php print $_SERVER['PHP_SELF']; ?>" method="POST">
			<div class='left'>
				First Name <br><br>
				Last Name <br><br>
				Address <br><br>
				City <br><br>
				State <br><br>
				Zipcode <br><br>
				DOB <br><br>
				SSN <br><br>
				<!-- Complete the form -->
				
				<br><br><button onclick='promptWarning("Add a student?", "addStudent.php")'> Submit Profile </button>
			</div>
			<div class='right'>
				 <input type='text' name='firstName'> <br><br>
				 <input type='text' name='lastName'> <br><br>
				 <input type='text' name='Address'> <br><br>
				 <input type='text' name='City'> <br><br>
				 <input type='text' name='State'> <br><br>
				 <input type='text' name='Zipcode'> <br><br>
				 <input type='text' name='DOB'> <br><br>
				 <input type='text' name='SSN'> <br><br>
				 <!-- Complete the form -->
			</div>
		
		</form>
		<?php
			# Your Code Starts Here ...	
			if($_SERVER["REQUEST_METHOD"] == 'POST' && isset($_SESSION['database'])){
				print $divRight;
					$myDB = $_SESSION['database'];
					
					$firstName = $_POST['firstName'];
					$lastName = $_POST['lastName'];
					$address = $_POST['address'];
					$city = $_POST['city'];
					$zipcode = $_POST['zipcode'];
					$dob = $_POST['dob'];
					$ssn = $_POST['ssn'];
					
					$student = new Student($firstName. $lastName, $address,
											$city, $state, $zipcode, $dob, $ssn, $myDB);
					$student->displayStudentInfo();
					
					$student->insertRecordInToTable();
				print $divEnd;
				
				header( "refresh:5;url=../index.php" );
			}
			
		?>
	</body>
</html>

