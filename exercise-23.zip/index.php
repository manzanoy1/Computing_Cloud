<!DOCTYPE html>
<html>
	<head>
		<title>Class Exercise 23</title>
		<link href="css/myStyle.css" rel="stylesheet">
	</head>
	<body>
		<?php
			session_start();
			
			include 'utility/htmlTags.php';
			include 'utility/database.php';
			include 'utility/exercise.php';
			include 'utility/student.php';
			
			print $div;
				print "$h1 Exercise 23 - Amazon RDS $h1End";
			print $divEnd;
			
			updateLearningObjective($learningObjectives, 
									'Connect to DB Instance you have created using Amazon RDS.');
			updateLearningObjective($learningObjectives, 
									'Insert a new record into the table using an HTML form and the PHP script.');
			updateLearningObjective($learningObjectives, 
									'Delete an existing record in the table using the PHP script.');
			updateLearningObjective($learningObjectives, 
									'Fetch raw data from tables, process it, and display it properly in the web page.');
			updateLearningObjective($learningObjectives, 
									'Close the database connection once you accomplish specified tasks.');
							
			printLearningObjectives($learningObjectives);
						
			updateRules($rules, 'There should not be any warnings/errors in your application.', 20);
			updateRules($rules, 'Upload a zip file containing all the code related files and folders.', 10);
			updateRules($rules, 'Print your web page (Ctrl + P) and upload the printed page on D2L 
								or upload snapshots of your updated web page.', 10);
		
		?>
					
		<?php
		
			printExamples("Print Database Connection Information: ");
			
			$myServer = 'cisc320-yanira-1.cwqya4upwyw5.us-east-2.rds.amazonaws.com';
			$myUserName = 'admin';
			$myPassword = 'h3254807';
			$databaseName = 'university';
			$myDB = new Database($myServer, $myUserName, $myPassword, $databaseName);
			$myDB->printConnectionDetails();
			
			$_SESSION['database'] = $myDB;
			
			printProblemsToSolve('Edit the connection related variables
									and connect to your cloud database successfully.', 5);
					
			$myDB->connectToDatabase();
			
			printExamples("Print All Records from Table students: ");
			$myDB->printRecords('students');
			$myDB->closeDatabaseConnection();
			
			printProblemsToSolve('Complete the file deleteStudent.php inside utility folder.
									The sample code is provided to you on D2L.', 25);
									
			printProblemsToSolve('Add a new record to your database using the form. Print the main page before and after adding a new record.', 15);
			
			printProblemsToSolve('Delete a random record and print the main page after deletion.', 15);
									
			print $div;
				print $p;
					printHyperLinks("Add Student", "utility/addStudent.php");
				print $pEnd;
			print $divEnd;
			
			printRules($rules);
		?>
	</body>
</html>