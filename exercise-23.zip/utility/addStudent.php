<!DOCTYPE html>
<html lang="en">
	<head>
		<title> Add Student Profile </title>
		<link href="../css/myStyle.css" type="text/css" rel="stylesheet">
		<script src='profile.js'> </script>
	</head>
	<body>
		<?php
			require 'database.php';
			require 'student.php';
			require 'htmlTags.php';
			session_start(); 
		?>
		<h1>ADD STUDENT'S PROFILE</h1>
		<form id='record' action="<?php print $_SERVER['PHP_SELF']; ?>" method="POST">
			<div class='left'>
				First Name <br><br>
				Last Name <br><br>
				Address <br><br>
				City <br><br>
				State <br><br>
				Zipcode <br><br>
				DOB <br><br>
				SSN <br>
				<br><br><button onclick='promptWarning("Add a student?", "addStudent.php")'> Submit Profile </button>
			</div>
			<div class='right'>
				 <input type='text' name='firstName'> <br><br>
				 <input type='text' name='lastName'> <br><br>
				 <input type='text' name='address'> <br><br>
				 <input type='text' name='city'> <br><br>
				 <input type='text' name='state'> <br><br>
				 <input type='text' name='zipcode'> <br><br>
				 <input type='text' name='dob'> <br><br>
				 <input type='text' name='ssn'> <br><br>
			</div>
		</form>
		
		<?php
			
			if($_SERVER["REQUEST_METHOD"] == 'POST' && isset($_SESSION['database'])){
				print $divRight;
					$myDB = $_SESSION['database'];
			
					$firstName = $_POST['firstName'];
					$lastName = $_POST['lastName'];
					$address = $_POST['address'];
					$city = $_POST['city'];
					$state = $_POST['state'];
					$zipcode = $_POST['zipcode'];
					$dob = $_POST['dob'];
					$ssn = $_POST['ssn'];
					
					$student = new Student($firstName, $lastName, $address,
											$city, $state, $zipcode, $dob, $ssn, $myDB);
					$student->displayStudentInfo();
					
					$student->insertRecordInToTable();
				print $divEnd;
				
				header( "refresh:5;url=../index.php" );
			}
		
		?>
	</body>
</html>