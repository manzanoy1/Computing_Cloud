function promptWarning(msg, nextPage){
	var submit = confirm(msg);
	if(submit){
		document.getElementById('record').action = nextPage;
	}
}

function showDeleteOption(myID){
	var userChoice = confirm('Do you want to delete this profile?');
	if(userChoice){
		document.getElementById(myID).style.visibility = 'visible';
		alert("Click the option [-]");
	}	
}