<!DOCTYPE html>
<html lang="en">
	<head>
		<title> Delete Profile </title>
		<link href="../css/myStyle.css" type="text/css" rel="stylesheet">
	</head>
	<body>		
		<h1>DELETE STUDENT PROFILE</h1>
		<?php
			
			require 'student.php';
			require 'database.php';
			require 'htmlTags.php';
			
			session_start();
			
			if($_SERVER["REQUEST_METHOD"] == 'GET' && isset($_SESSION['database'])){
				$studentID = $_GET['id'];
						
				$myDB = $_SESSION['database'];
				
				$myStudent = new Student('', '', '', '', '', '', '', '', $myDB);
				$myStudent->deleteStudent($studentID);
				
				header( "refresh:3;url=../index.php" );
			}
			

		?>
	</body>
</html>