<?php
	
	/*
		Copyright @ Romas James Hada
	*/
	
	$maxPoints = 0;
	$exampleCount = 0;
	$problemCount = 0;

	$learningObjectives = array();
	$rules = array();
	
	function updateLearningObjective(&$myArray, $objective){
		array_push($myArray, $objective);
	}
	
	
	function updateRules(&$myArray, $rule, $points){
		$myArray[$rule] = $points;
		updateScore($points);
	}
	
	function updateScore($score){
		global $maxPoints;
		$maxPoints += $score;
	}

	function printLearningObjectives($myArray){
		global $ul, $ulEnd, $li, $liEnd, $div, $divEnd, $p, $pEnd;
		print "$p Today You Will Learn To: $pEnd";
		print $div;
			print $ul;
				foreach($myArray as $item){
					print "$li $item $liEnd";
				}
			print $ulEnd;
		print $divEnd;
	}
	
	function printProblemsToSolve($problem_description, $points){
		global $div, $divEnd, $p, $pEnd, $problemCount;
		++$problemCount;
		print $div;
			print "$p Problem $problemCount: $problem_description ($points Points) $pEnd";
			updateScore($points);
		print $divEnd;
	}
	
	function printExamples($example_description){
		global $div, $divEnd, $p, $pEnd, $exampleCount;
		++$exampleCount;
		print $div;
				print "$p Example $exampleCount: $example_description $pEnd";
		print $divEnd;
	}
	
	function printRules($rules){
		global $ul, $ulEnd, $li, $liEnd, $div, $divEnd, $p, $pEnd, $maxPoints, $b, $bEnd;
		print "$p Submission Rules: $pEnd";
		print $div;
			print $ul;
				foreach($rules as $item => $score){
					print "$li $item ($score Points) $liEnd";
				}
				
				print "$li Max Points: $b $maxPoints $liEnd $bEnd";
			print $ulEnd;
		print $divEnd;
	}
	
	function printHyperLinks($text, $link){
		print "<a href=$link> $text </a>";
	}
?>