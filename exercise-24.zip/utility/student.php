<?php
	
	/*
		Copyright @ Romas James Hada
	*/
	
	class Student{
		private $firstName;
		private $lastName;
		private $address;
		private $city;
		private $state;
		private $zipcode;
		private $dob;
		private $ssn;
		private $myDBInstance;
		
		function __construct($firstName, $lastName, $address, 
								$city, $state, $zipcode, 
								$dob, $ssn, $dbInstance){
			$this->firstName = $firstName;
			$this->lastName = $lastName;
			$this->address = $address;
			$this->city = $city;
			$this->state = $state;
			$this->zipcode = $zipcode;
			$this->dob = $dob;
			$this->ssn = $ssn;
			$this->myDBInstance = $dbInstance;
		}
			
		function displayStudentInfo(){
			global $ul, $ulEnd, $li, $liEnd, $div, $divEnd;
			
			print $div;
				print $ul;
					print "	$li First Name: $this->firstName $liEnd
							$li Last Name: $this->lastName $liEnd
							$li Address: $this->address $liEnd
							$li City: $this->city $liEnd
							$li State: $this->state $liEnd
							$li Zipcode: $this->zipcode $liEnd
							$li Date of Birth: $this->dob $liEnd
							$li SSN: $this->ssn $liEnd
						";
				print $ulEnd;
			print $divEnd;
			
		}
		
		function fetchStudentRecord($studentID){
			$myDB = $this->myDBInstance;
			try{
				$myDB->connectToDatabase();
				
				$sql = "SELECT *
						FROM students
						WHERE student_id = $studentID
						";
				
				$result = $myDB->getConnection()->query($sql);
				$studentRecord = $result->fetch_assoc();
				
				# unset($studentRecord['student_id']);
				
				$myDB->closeDatabaseConnection();
				
				return $studentRecord;
				
			}catch(Exception $e){
				print $e->getMessage();
			}
		}
		
		function updateRecord($studentID){
			$myDB = $this->myDBInstance;
			try{
				$myDB->connectToDatabase();
				
				$sql = "UPDATE students 
						SET student_first_name = '$this->firstName',
							student_last_name = '$this->lastName',
							student_address = '$this->address',
							student_city = '$this->city',
							student_state = '$this->state',
							student_zipcode = '$this->zipcode',
							student_dob = '$this->dob',
							student_ssn = '$this->ssn'
						WHERE student_id = $studentID;
						";
				
				$myDB->executeQueryToInsertOrUpdateRows($sql);
				
				$myDB->closeDatabaseConnection();
				
			}catch(Exception $e){
				print $e->getMessage();
			}
		}
		
		function insertRecordInToTable(){
			$myDB = $this->myDBInstance;
			try{
				$myDB->connectToDatabase();
				
				$sql = "INSERT INTO students (student_first_name, student_last_name, 
										  student_address, student_city, student_state, student_zipcode, 
										  student_dob, student_ssn) 
						VALUES ('$this->firstName', '$this->lastName', 
								'$this->address', '$this->city', '$this->state', 
								'$this->zipcode', '$this->dob', '$this->ssn')
						";
				
				$myDB->executeQueryToInsertOrUpdateRows($sql);
				
				$myDB->closeDatabaseConnection();
				
			}catch(Exception $e){
				print $e->getMessage();
			}
		}
		
		function deleteStudent($studentID){
			$myDB = $this->myDBInstance;
			try{
				$myDB->connectToDatabase();
				
				$sql = "DELETE FROM students
						WHERE student_id = $studentID;
						";
				
				$myDB->executeQueryToInsertOrUpdateRows($sql);
				
				$myDB->closeDatabaseConnection();
				
			}catch(Exception $e){
				print $e->getMessage();
			}
		}
	}
?>