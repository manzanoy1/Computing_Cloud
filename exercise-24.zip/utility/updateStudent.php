<!DOCTYPE html>
<html lang="en">
	<head>
		<title> Update Student Profile </title>
		<link href="../css/myStyle.css" type="text/css" rel="stylesheet">
	</head>
	<body>
		<?php
			require 'database.php';
			require 'student.php';
			require 'htmlTags.php';
			session_start(); 
		?>
		<h1>UPDATE STUDENT'S PROFILE</h1>
		<form id='record' action="<?php print $_SERVER['PHP_SELF']; ?>" method="POST">
			<div class='left'>
				Student ID <br><br>
				First Name <br><br>
				Last Name <br><br>
				Address <br><br>
				City <br><br>
				State <br><br>
				Zipcode <br><br>
				DOB <br><br>
				SSN <br>
				<br><br><button> Update Profile </button>
			</div>
		<?php
			# Your Code Starts Here
			$inputNames = array('id', 'firstName', 'lastName', 'address',
								'city', 'state', 'zipcode', 'dob', 'ssn');
								
			print $divRight;
			
			if($_SERVER["REQUEST_METHOD"] == 'GET' && isset($_SESSION['database'])){
				$myDB = $_SESSION['database'];
				$studentID = $_GET['id'];
				
				#creating a default instance of class student
				$student = new Student('', '', '', '', '', '', '', '', $myDB);
				$studentRecordArray = $student->fetchStudentRecord($studentID);
				
				#fetch record and filling out the form
				$index = 0;
				
				foreach($studentRecordArray as $key=>$value){
					printInputTags('text', $inputNames[$index], $value);
					$index++;
				}
			}else if($_SERVER["REQUEST_METHOD"] == 'POST' && isset($_SESSION['database'])){
				$myDB = $_SESSION['database'];
				
				$id = $_POST['id'];
				$firstName = $_POST['firstName'];
				$lastName = $_POST['lastName'];
				$address = $_POST['address'];
				$city = $_POST['city'];
				$state = $_POST['state'];
				$zipcode = $_POST['zipcode'];
				$dob = $_POST['dob'];
				$ssn = $_POST['ssn'];
				
				$student = new Student($firstName, $lastName, $address,
										$city, $state, $zipcode, $dob, $ssn, $myDB);
				$student->displayStudentInfo();
				
				$student->updateRecord($id);
				
				header( "refresh:5;url=../index.php" );
			}else{
				print "Something went wrong :[";
			}
			
			print $divEnd;
	
		?>
		
		</form>
		
		<?php
			function printInputTags($inputType, $name, $value){
				global $lineBreak;
				print "<input type='$inputType' name='$name' value='$value'> $lineBreak $lineBreak";
			}
		?>
	</body>
</html>