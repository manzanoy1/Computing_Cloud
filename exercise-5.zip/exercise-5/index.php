<!DOCTYPE html>
<html lang="en">
	<head>
		<title>PHP</title>
		<link href="css/exercises.css" type="text/css" rel="stylesheet">
		<link href="images/Hartwick_Logo_3.jpg" type="image/jpeg" rel="shortcut icon">
	</head>
	<body>
		<?php # this line indicates start of php code
		   /* This is a comment. 
		    Today, we will learn PHP, HTML5, and CSS.
			Using print statment to print a heading defined 
			by tags <h1> and </h1>.
		   */
			print "<h1> HTML headings are defined with the &lt;h1&gt; to &lt;h6&gt; tags. </h1>";
			
			
			# Defining a variable to store a string.
			$heading1 = "<h1> Heading 1 </h1>";
			$heading2 = "<h2> Heading 2 </h2>";
			$heading3 = "<h3> Heading 3 </h3>";
			
			# create variables $heading4, $heading5, and $heading6 and store respective 
			# strings representing headings ranging from 4 to 6 below (15 Points).
			
			$heading4 = "<h4> Heading 4 </h4>";
			$heading5 = "<h5> Heading 5 </h5>";
			$heading6 = "<h6> Heading 6 </h6>";
			
			print $heading1;
			print $heading2;
			print $heading3;
			
			// print the headings using print statement as shown above (15 Points).
					
			print $heading4;
			print $heading5;
			print $heading6;
			
		
			# Now, let's learn about Strings in PHP
			
			# <p> tag to indicate that HTML paragraph starts here.
			
			print '<p>'; 
			# we can use both single and double quotes to represent a string.
				$favorite_food = "Ethiopian"; #create a variable that stores a string "Ethiopian."
				print '<br>';	# prints a new line (break) in your HTML page.
				print $favorite_food[2]; # prints the third character of word stored inside $favorite_food.
				print '<br>';
				
				$favorite_food = $favorite_food . " cuisine"; # string concatenation
				
				print $favorite_food; 
				
				print '<br>';	

				# more example of string concatenation				
				print 'My favorite food is ' 
						. $favorite_food[2] 
						. strtolower($favorite_food[0])
						. $favorite_food[-2];
						
				# more string related functions
				$name = "Stefanie Hatcher";
				# this function returns the length of the string stored inside $name.
				$length = strlen($name); 
				print '<br>';
				print $length;
				print '<br>';
				# this function returns the position of the string "e" in the string stored inside $name.
				$index = strpos($name, "e"); 
				print $index;
				print '<br>';
				# this function returns a substring of length 5 starting at position 9.
				$first = substr($name, 9, 5); 
				print $first;
				print '<br>';
				$name = strtoupper($name); # all caps
				print $name;
				print '<br>';
				print $first == 'Hatch'; # string comparison
				print '<br>';
				print $first != 'hatch'; # string comparison
				print '<br>';
				# create a variable '$myFirstName' and assign a value (your first name) to this variable. (10 Points).
				$myFirstName = "Yanira";
				# create a another variable '$myLastName' and assign a value (your last name) to this variable. (10 Points).
				$myLastName = "Manzano";
				# create another variable $myFullName. 
				$myFullName = "$myFirstName $myLastName";
				# Concatenate values stored inside $myFirstName and $myLastName and assign to $myFullName. (10 Points)
				# print the value stored inside $myFullName (10 Points).
				print $myFullName;
			# </p> tag to indicate that HTML paragraph ends here.
			print '</p>';
		# the line shown below indicates end of php code	
		?>
		
		<!-- Upload this file (index.php) on D2L along with the public link to your website and snapshot of your page (20 Points).-->
	</body>
</html>