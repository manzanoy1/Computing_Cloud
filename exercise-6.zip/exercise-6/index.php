<!DOCTYPE html>
<html>
	<head>
		<title>Exercise 6 - PHP Basics</title>
		<link href="css/myStyle.css" rel="stylesheet">
	</head>
	<body>
		<?php
			$h1 = '<h1>';
			$h1End = '</h1>';
			
			print "$h1 Exercise 6 - HTML, CSS, and PHP Basics to Host a Dynamic Website in the Cloud. $h1End";
			
			$divClass = 'exercise';
			
			$x = 10;
			$y = 7;
			
			$tr = '<tr>'; # Indicates start of row in a table
			$trEnd = '</tr>'; # Indicates end of row in a table
			
			$td = "<td>"; # Indicates start of a cell in a table
			$tdEnd = "</td>"; # Indicates end of a cell in a table
			
			$table = "<table>"; #Indicates start of a table in an HTML page
			$tableEnd = "</table>"; #Indicates start of a table in an HTML page
			
			$div = "<div class=$divClass>";
			$divEnd = "</div>";
			
			$p = "<p>"; # start of a paragraph
			$pEnd = "</p>";
			
			$lineBreak = '<br>'; #line break in HTML page
			$lessThan = '&lt;';
			$greaterThan = '&gt;';
			
			print $p;
				print "After completion of this exercise, you will learn to:
				$linebreak 1. Create HTML tables using table related
				tags such as $lessThan table and $greaterThan, $lessThan tr $greaterThan, and $lessThan td $greaterThan.
				$lineBreak 2. Create sections in your web page using tags such as $lessThan div $greaterThan and $lessThan/div $greaterThan.
				";	
			print $pEnd;
			
		?>
		
		<?php
			print $div;
				print $table;
					print "$tr $td Name: $tdEnd $td Yanira Manzano $tdEnd $trEnd
					$tr $td ID: $tdEnd $td 3254807 $tdEnd $trEnd
					$tr $td Course ID: $tdEnd $td CISC 320 $tdEnd $trEnd
					$tr $td Course: $tdEnd $td Computing in the Cloud $tdEnd $trEnd
					$tr $td Project Title: $tdEnd $td Interactive Resume/Portfolio Website. $tdEnd $trEnd
					$tr $td Description of your Project: $tdEnd $td Create a Resume/Portfolio Website with interactive links to go and see more details of each project. $tdEnd $trEnd
					";
				print $tableEnd;
			print $divEnd;
		?>
	</body>
</html>