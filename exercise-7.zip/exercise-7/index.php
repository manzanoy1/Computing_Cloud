<!DOCTYPE html>
<html>
	<head>
		<title>Exercise 7 - PHP Basics (Math Operators)</title>
		<link href="css/myStyle.css" rel="stylesheet">
	</head>
	<body>
		<?php
			$h1 = '<h1>';
			$h1End = '</h1>';
			
			print "$h1 Exercise 7 - Using Math Operators in PHP. $h1End";
			
			$divClass = 'exercise'; # one of the classes defined in CSS file, myStyle.css inside css folder.
			
			$x = 10;
			$y = 7;
			
			$tr = '<tr>'; # store <tr> tag inside $tr variable. <tr> indicates start of row in a table.
			$trEnd = '</tr>'; # store </tr> tag inside $trEnd variable. </tr> indicates end of a row in a table.
			
			$td = "<td>"; # store <td> tag inside $td variable. <td> indicates start of a cell in a table.
			$tdEnd = "</td>"; # store </td> tag inside $tdEnd variable. </td> indicates end of a cell in a table.
			
			$table = "<table>"; # store <table> tag inside $table variable. <table> indicates start of a table in an HTML page.
			$tableEnd = "</table>"; # store </table> tag inside $tableEnd variable. </table> indicates end of a table in an HTML page.
			
			$div = "<div class=$divClass>"; # <div class='exercise'> indicates start of a new section that falls under 'exercise' class (CSS).
			$divEnd = "</div>"; # </div> indicates end of the section.
			
			$p = "<p>"; # <p> indicates start of a paragraph in an HTML page.
			$pEnd = "</p>"; # </p> indicates end of a paragraph in an HTML page.
			
			$lineBreak = '<br>'; # line break in HTML page.
			$lessThan = '&lt;'; # '<' symbol
			$greaterThan = '&gt;'; # '>' symbol
			
			#20 Points	
			print $p;
				print "After completion of this exercise, you will learn to:
				$lineBreak 1. Create HTML tables using table related
				tags such as $lessThan table $greaterThan, $lessThan tr $greaterThan, and $lessThan td $greaterThan.
				$lineBreak 2. Create sections in your web page using tags such as $lessThan div $greaterThan and $lessThan/div $greaterThan.
				$lineBreak 3. Use math operators in PHP
				";
			print $pEnd;
			
		?>
					
		<?php
			# 40 Points
			print $div;
				print $table;
				print "$tr $td $x + $y = " . ($x + $y) . " $tdEnd $trEnd
						$tr $td $x - $y = " . ($x - $y) . " $tdEnd $trEnd
						$tr $td $x * $y = " . ($x * $y) . " $tdEnd $trEnd
						$tr $td $x / $y = " . ($x / $y) . " $tdEnd $trEnd
						$tr $td $x % $y = " . ($x % $y) . " $tdEnd $trEnd
						$tr $td x++ + y = " . ($x++ + $y) . " $tdEnd $trEnd
						$tr $td ++x + y = " . (++$x + $y) . " $tdEnd $trEnd
						$tr $td $x<sup>2</sup> = " . ($x ** 2) . " $tdEnd $trEnd";
				print $tableEnd;
			print $divEnd;
						
			/*
				1. There should be no errors in your code (10 Points).
				2. You should provide a public link to your website 
				and I should be able to access it (20 Points).
				3. Upload index.php and a snapshot of your page (10 Points).
			*/
		?>
	</body>
</html>