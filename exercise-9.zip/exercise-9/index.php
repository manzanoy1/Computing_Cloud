<!DOCTYPE html>
<html>
	<head>
		<title>Exercise 9 - PHP Basics (If Else If Else and For Loops)</title>
		<link href="css/myStyle.css" rel="stylesheet">
	</head>
	<body>
		<?php
			$h1 = '<h1>';
			$h1End = '</h1>';
			
			print "$h1 Exercise 9 - PHP Basics (Conditional Statements and For Loops) $h1End";
			
			$divClass = 'exercise'; # one of the classes defined in CSS file, myStyle.css inside css folder.
			
			$tr = '<tr>'; # store <tr> tag inside $tr variable. <tr> indicates start of row in a table.
			$trEnd = '</tr>'; # store </tr> tag inside $trEnd variable. </tr> indicates end of a row in a table.
			
			$th = '<th>'; # table header
			$thEnd = '</th>'; # end of table header
			
			$td = "<td>"; # store <td> tag inside $td variable. <td> indicates start of a cell in a table.
			$tdEnd = "</td>"; # store </td> tag inside $tdEnd variable. </td> indicates end of a cell in a table.
			
			$table = "<table>"; # store <table> tag inside $table variable. <table> indicates start of a table in an HTML page.
			$tableEnd = "</table>"; # store </table> tag inside $tableEnd variable. </table> indicates end of a table in an HTML page.
			
			$div = "<div class=$divClass>"; # <div class='exercise'> indicates start of a new section that falls under 'exercise' class (CSS).
			$divEnd = "</div>"; # </div> indicates end of the section.
			
			$p = "<p>"; # <p> indicates start of a paragraph in an HTML page.
			$pEnd = "</p>"; # </p> indicates end of a paragraph in an HTML page.
			
			$lineBreak = '<br>'; # line break in HTML page.
			$lessThan = '&lt;'; # '<' symbol
			$greaterThan = '&gt;'; # '>' symbol
			
		
			print $p;
				print "After completion of this exercise, you will learn to:
				       $lineBreak 1. Use conditional statements in PHP.
					   $lineBreak 2. Use loops (for, while, and do while loops).
					   ";
			print $pEnd;
		?>
					
		<?php
		
			# 30 Points
			# Modify the code below to represent grading scheme for this course (A, A-, B+, B, B-, ...).
			$score = mt_rand(0, 100); # randomly generate integer between 0 and 100.
			print $div;
				print "$p Problem 1: Modify existing code to represent grading scheme for this course (A, A-, B+, B, B-, ...) (30 Points) $pEnd";
				print "$p Your Score is $score out of 100. $pEnd";
				if($score >= 93){
					print "$p Your letter grade is A. $pEnd";
				}else if($score >=  92 && $score <93){
					print "$p Your letter grade is A-. $pEnd";
				}else if($score >= 89 && $score < 90){
					print "$p Your letter grade is B+. $pEnd";
				}else if($score >= 86 && $score < 89){
					print "$p Your letter grade is B. $pEnd";
				}else if($score >= 83 && $score < 84){
					print "$p Your letter grade is B-. $pEnd";
				}else if($score >= 79 && $score < 80){
					print "$p Your letter grade is C+. $pEnd";
				}elseif($score >= 76 && $score < 77){
					print "$p Your letter grade is C. $pEnd";
				}else if($score >= 73 && $score < 74){
					print "$p Your letter grade is C-. $pEnd";
				}else if($score >= 69 && $score < 70){
					print "$p Your letter grade is D+. $pEnd";
				}else if($score >= 66 && $score < 67){
					print "$p Your letter grade is D. $pEnd";
				}else if($score >= 63 && $score < 64){
					print "$p Your letter grade is D-. $pEnd";
				}else{
					print "$p Your letter grade is F. $pEnd";
				}
			print $divEnd;
			
			print $div;
				# create a table with three rows and two columns
				print "$p Example 1: Printing a table using print statements. $pEnd";
				print $table;
					print "$tr $th First Column $thEnd $th Second Column $thEnd $trEnd";
					print "$tr $td This is row 0, column 1 $tdEnd $td This is row 0, column 2 $tdEnd $trEnd";
					print "$tr $td This is row 1, column 1 $tdEnd $td This is row 1, column 2 $tdEnd $trEnd";
					print "$tr $td This is row 2, column 1 $tdEnd $td This is row 2, column 2 $tdEnd $trEnd";
				print $tableEnd;
			print $divEnd;
			
			# create another section
			print $div;
				print "$p Example 2: Printing a table using a for loop. $pEnd";
				$numRows = 3;
				print $table;
					print "$tr $th First Column $thEnd $th Second Column $thEnd $trEnd";
					for($rows = 0; $rows < $numRows; $rows++){
						print "$tr $td This is row $rows, column 1 $tdEnd $td This is row $rows, column 2 $tdEnd $trEnd";
					}
				print $tableEnd;
			print $divEnd;
			
			print $div;
				print "$p Problem 2: Print a table with 3 rows and 3 columns using a for loop. 
						Please take a look at the sample output (10 Points). $pEnd";
				# Type your code here.
				$numRows = 3;
				print $table;
					print "$tr $th First Column $thEnd $th Second Column $thEnd $th Third Column $trEnd";
					for($rows = 0; $rows < $numRows; $rows++){
						print "$tr $td This is row $rows, column 1 $tdEnd $td This is row $rows, column 2 $tdEnd $td This is row $rows, column 3 $tdEnd $trEnd";
					}
				print $tableEnd;
				
			print $divEnd;
			
			/*	
				An example of table using nested for loops.
			*/
			$numRows = 5;
			$numColumns = 5;
			$cloud = '&#9729;'; # unicode to display cloud symbol in HTML
			$sun = '&#9728;'; # unicode to display sun symbol in HTML
			$umbrella = '&#9730;'; # unicode to display umbrella symbol in html
			
			print $div;
				print "$p Example 3: Printing a table using a nested for loops. 
						First for loop represents rows while the second one represents columns. $pEnd";
				
				print $table;
					for($rows = 0; $rows < $numRows; $rows++){
						print $tr;
							for($columns = 0; $columns < $numColumns; $columns++){
								print "$td ($rows, $columns) $tdEnd";
							}
						print $trEnd;
					}
				print $tableEnd;
			print $divEnd;
			
			print $div;
				print "$p Problem 3: Print a table using a nested for loops. 
						First for loop represents rows while the second one represents columns (10 Points). $pEnd";
							
				# Your code starts here.
				
				print $table;
					for($rows = 0; $rows < $numRows; $rows++){
						print $tr;
							for($columns = 0; $columns < $numColumns; $columns++){
								if($rows == intdiv($numRows, 2) && $columns == intdiv($numColumns, 2))
									print "$td $sun $tdEnd";
								else if($rows%2 == 0)
									print "$td $cloud $tdEnd";
								else
									print "$td $umbrella $tdEnd";
							}
						print $trEnd;
					}
				print $tableEnd;
				
				print "$p
						Replace line with the original code else if(\$rows == \$columns) by else if(\$rows%2 == 0) and refresh your page. $lineBreak
						Did you notice the difference? $lineBreak -Yes
						Can you explain why the change in the line led to the change in the content of the table? 
						Please explain in detail. (20 Points) -The reason why it change it to this table from umbrella to cloud, because the $/rows is == to 0. Each row from each column does 0, 1, 2 and then repeat. The $/numRows are 2.
					$pEnd
				";
				
			print $divEnd;
			
			print $div;
				print "$p
						1. There should be no errors in your code (10 Points). $lineBreak
						2. You should provide a public link to your website 
					and I should be able to access it (10 Points). $lineBreak
						3. Upload index.php and a snapshot of your page (10 Points). $lineBreak
					$pEnd
				";
			print $divEnd;
		?>
	</body>
</html>